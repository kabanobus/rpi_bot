from ament_index_python.packages import get_package_share_directory
import launch
from launch.actions import RegisterEventHandler
from launch.event_handlers import OnProcessStart
from launch_ros.actions import Node
import xacro
import os

def generate_launch_description():
    pkg_name = 'vacuum_cleaner'
    model_subpath = 'description/robot.urdf.xacro'

    pkg_share = get_package_share_directory(pkg_name)
    model_path = os.path.join(pkg_share, model_subpath)
    robot_description_raw = xacro.process_file(model_path).toxml()

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': robot_description_raw}]
    )
    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher'
    )

    controller_manager = Node(
        package='controller_manager',
        executable='ros2_control_node',
        parameters=[os.path.join(pkg_share, 'config', 'controllers.yaml')],
        remappings=[
            ('~/robot_description', '/robot_description')
            # ('/diff_controller/cmd_vel', '/cmd_vel')
        ]
    )

    diff_drive_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['diff_controller'],
        # ros_arguments=['--log-level', 'DEBUG']
    )
    joint_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_broadcaster'],
    )

    delayed_diff_drive_spawner = RegisterEventHandler(
        event_handler=OnProcessStart(
            target_action=controller_manager,
            on_start=[diff_drive_spawner],
        )
    )
    delayed_joint_broad_spawner = RegisterEventHandler(
        event_handler=OnProcessStart(
            target_action=controller_manager,
            on_start=[joint_broadcaster_spawner],
        )
    )

    lidar_scanner = Node(
        package='mb_1r2t',
        executable='mb_1r2t_node',
        parameters=[{
            'frame_id': 'lidar_link',
            'port': '/dev/serial0'
        }]
    )

    return launch.LaunchDescription([
        robot_state_publisher_node,
        # joint_state_publisher_node, 
        controller_manager, 
        delayed_diff_drive_spawner,
        delayed_joint_broad_spawner,
        lidar_scanner
    ])