#include "vacuum_cleaner_hardware/rpi_hw_system.hpp"

#include <cassert>

#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "pluginlib/class_list_macros.hpp"

#include "pigpio.h"

namespace vacuum_cleaner_hardware {

RpiHwSystem::RpiHwSystem() :
    logger_(rclcpp::get_logger("RpiHwSystem"))
{
    
};

hardware_interface::CallbackReturn RpiHwSystem::on_init(const hardware_interface::HardwareInfo &hw_info)
{
    if (SystemInterface::on_init(hw_info) != CallbackReturn::SUCCESS) {
        return CallbackReturn::ERROR;
    }
    
    if (info_.joints.size() != 2)
    {
        RCLCPP_FATAL(
            logger_,
            "Hardware entry has %zu joints found. 2 expected.",
            info_.joints.size()
        );
        return CallbackReturn::ERROR;
    }
    
    const std::string &left_motor_joint = info_.hardware_parameters.at("left_motor_joint");
    const std::string &right_motor_joint = info_.hardware_parameters.at("right_motor_joint");

    if (info_.joints[0].name == right_motor_joint) {
        if (info_.joints[1].name != left_motor_joint) {
            RCLCPP_FATAL(logger_, "No joint named %s for the left motor", left_motor_joint.c_str());
            return CallbackReturn::ERROR;
        }
    } else if (info_.joints[1].name == right_motor_joint) {
        if (info_.joints[0].name != left_motor_joint) {
            RCLCPP_FATAL(logger_, "No joint named %s for the left motor", left_motor_joint.c_str());
            return CallbackReturn::ERROR;
        }
    } else {
        RCLCPP_FATAL(logger_, "No joint named %s for the right motor", right_motor_joint.c_str());
        return CallbackReturn::ERROR;
    }

    // exactlty one 'velocity' command interface and two state interfaces ('velocity' and 'position') on each joint
    auto check_joint_interfaces = [this](hardware_interface::ComponentInfo &joint) -> CallbackReturn {
        assert(joint.type == "joint");

        if (!(
                joint.command_interfaces.size() == 1 &&
                joint.command_interfaces[0].name == hardware_interface::HW_IF_VELOCITY
        )) {
            RCLCPP_FATAL(
                logger_,
                "Joint '%s' must have only one command interface, and it's type must be 'velocity'.",
                joint.name.c_str()
            );
            return CallbackReturn::ERROR;
        }
        if (!(
                joint.state_interfaces.size() == 2 &&
                ((
                    joint.state_interfaces[0].name == hardware_interface::HW_IF_POSITION &&
                    joint.state_interfaces[1].name == hardware_interface::HW_IF_VELOCITY
                ) || (
                    joint.state_interfaces[0].name == hardware_interface::HW_IF_VELOCITY &&
                    joint.state_interfaces[1].name == hardware_interface::HW_IF_POSITION
                ))
        )) {
            RCLCPP_FATAL(
                logger_,
                "Joint '%s' must have exactly two state interfaces, and their types must be 'velocity' and 'position'.",
                joint.name.c_str()
            );
            return CallbackReturn::ERROR;
        }
        return CallbackReturn::SUCCESS;   
    };

    if (check_joint_interfaces(info_.joints[0]) != CallbackReturn::SUCCESS ||
        check_joint_interfaces(info_.joints[1]) != CallbackReturn::SUCCESS
    ) {
        return CallbackReturn::ERROR;
    }

    left_motor_joint_ = left_motor_joint;
    right_motor_joint_ = right_motor_joint;

    gpioCfgInterfaces(PI_DISABLE_FIFO_IF | PI_DISABLE_SOCK_IF);
    if(gpioInitialise() == PI_INIT_FAILED) {
        RCLCPP_FATAL(logger_, "Failed to initialize pigpio library");
        return CallbackReturn::ERROR;
    }

    if ((i2c_handle_ = i2cOpen(1, 0x42, 0)) < 0) {
        RCLCPP_FATAL(logger_, "Unable to open i2c device");
        return CallbackReturn::ERROR;
    }

    RCLCPP_INFO(logger_, "Initialized");
    return hardware_interface::CallbackReturn::SUCCESS;
};

std::vector<hardware_interface::StateInterface> RpiHwSystem::export_state_interfaces()
{
    std::vector<hardware_interface::StateInterface> state_interfaces;
    state_interfaces.emplace_back(right_motor_joint_, hardware_interface::HW_IF_POSITION, &right_motor_state_pos_);
    state_interfaces.emplace_back(right_motor_joint_, hardware_interface::HW_IF_VELOCITY, &right_motor_state_vel_);
    state_interfaces.emplace_back(left_motor_joint_, hardware_interface::HW_IF_POSITION, &left_motor_state_pos_);
    state_interfaces.emplace_back(left_motor_joint_, hardware_interface::HW_IF_VELOCITY, &left_motor_state_vel_);
    return state_interfaces;
}

std::vector<hardware_interface::CommandInterface> RpiHwSystem::export_command_interfaces()
{
    std::vector<hardware_interface::CommandInterface> state_interfaces;
    state_interfaces.emplace_back(right_motor_joint_, hardware_interface::HW_IF_VELOCITY, &right_motor_cmd_vel_);
    state_interfaces.emplace_back(left_motor_joint_, hardware_interface::HW_IF_VELOCITY, &left_motor_cmd_vel_);
    return state_interfaces;
}

hardware_interface::CallbackReturn RpiHwSystem::on_activate(const rclcpp_lifecycle::State &prev_state)
{
    (void)prev_state;

    RCLCPP_INFO(logger_, "Activated");
    return CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn RpiHwSystem::on_deactivate(const rclcpp_lifecycle::State &prev_state)
{
    (void)prev_state;
    
    if (i2cClose(i2c_handle_) != 0) {
        RCLCPP_FATAL(logger_, "Unable to close i2c device (already closed?)");
        return CallbackReturn::ERROR;
    }
    RCLCPP_INFO(logger_, "Deactivated");
    return CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn RpiHwSystem::on_shutdown(const rclcpp_lifecycle::State &prev_state)
{
    (void)prev_state;
    
    gpioTerminate();
    RCLCPP_INFO(logger_, "Shutting down");
    return CallbackReturn::SUCCESS;
}
hardware_interface::CallbackReturn RpiHwSystem::on_error(const rclcpp_lifecycle::State &prev_state)
{
    (void)prev_state;
    
    RCLCPP_INFO(logger_, "Error!");
    return CallbackReturn::ERROR;
}

hardware_interface::return_type RpiHwSystem::read(const rclcpp::Time &time, const rclcpp::Duration &period)
{
    (void)time;
    (void)period;

    // 4-byte float velocity of the right motor, then for the left
    char data[8];
    if(i2cReadDevice(i2c_handle_, data, sizeof data) != sizeof data) {
        RCLCPP_FATAL(logger_, "Failed to read states from the i2c slave");
        return hardware_interface::return_type::ERROR;
    }
    right_motor_state_vel_ = (double)*(float *)&data[0];
    left_motor_state_vel_ = (double)*(float *)&data[4];
    right_motor_state_pos_ = 0.0;
    left_motor_state_pos_ = 0.0;

    return hardware_interface::return_type::OK;
}

hardware_interface::return_type RpiHwSystem::write(const rclcpp::Time &time, const rclcpp::Duration &period)
{
    (void)time;
    (void)period;
    
    // RCLCPP_INFO(logger_, "Writing: %f %f", right_motor_cmd_vel_, left_motor_cmd_vel_);

    struct __attribute__((packed)) {
        float right_vel, left_vel;
        uint8_t other;
    } packet = {
        (float)right_motor_cmd_vel_, (float)left_motor_cmd_vel_,
        0
    };
    static_assert(sizeof packet == 9);

    int attempts = 5;
    while ((i2cWriteDevice(i2c_handle_, (char *)&packet, sizeof packet) != 0) && attempts--) {}
    if (attempts == 0) {
        RCLCPP_FATAL(logger_, "Failed to write command to the i2c slave");
        return hardware_interface::return_type::ERROR;
    }
    return hardware_interface::return_type::OK;
}

}  // namespace vacuum_cleaner_hardware

PLUGINLIB_EXPORT_CLASS(vacuum_cleaner_hardware::RpiHwSystem, hardware_interface::SystemInterface)
