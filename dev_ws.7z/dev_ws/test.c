#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <linux/prctl.h>
#include <linux/capability.h>
#include <string.h>
#include "pigpio.h"

int main()
{
    gpioInitialise();

    int handle = i2cOpen(1, 0x42, 0);
    if (handle < 0) {
        printf("):\n");
        return -1;
    }

    float r = 0.0, l = 0.0;
    char data[9];
    memcpy(&data[0], (char *)&r, sizeof r);
    memcpy(&data[4], (char *)&l, sizeof l);
    data[8] = 0;

    printf("%d\n", i2cWriteDevice(handle, data, sizeof data));

    char data2[8];
    printf("%d\n", i2cReadDevice(handle, data2, sizeof data2));
    printf("%f %f\n", *(float *)&data2[0], *(float *)&data2[4]);

    if (i2cClose(handle) != 0) {
        printf("));\n");
    }

    gpioTerminate();
    return 0;
}
